export default function Sidebar({ activeSection, setActiveSection }) {
  return (
    <aside className="space-y-4">
      <button onClick={() => setActiveSection('properties')} className="block w-full text-left">Properties</button>
      <button onClick={() => setActiveSection('designs')} className="block w-full text-left">Design Gallery</button>
      <button onClick={() => setActiveSection('dashboard')} className="block w-full text-left">Dashboard</button>
    </aside>
  );
}