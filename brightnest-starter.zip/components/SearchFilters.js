import { useState } from 'react';
const filterData = {
  location: ['Lagos', 'Abuja', 'Port Harcourt'],
  price: ['500000', '1000000', '2000000'],
  type: ['Apartment', 'Duplex', 'Studio'],
  status: ['For Sale', 'For Rent'],
};
export default function SearchFilters() {
  const [filters, setFilters] = useState({ location: '', price: '', type: '', status: '' });
  const handleChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };
  return (
    <section className="p-4 bg-white shadow mt-2">
      <input type="text" placeholder="Search..." className="border p-2 w-full mb-2" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {Object.entries(filterData).map(([key, options]) => (
          <select key={key} className="border p-2" onChange={e => handleChange(key, e.target.value)}>
            <option value="">{key[0].toUpperCase() + key.slice(1)}</option>
            {options.map(opt => (<option key={opt} value={opt}>{opt}</option>))}
          </select>
        ))}
      </div>
    </section>
  );
}