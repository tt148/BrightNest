const dashboardItems = [
  { id: 1, label: 'Saved Homes', image: '/images/saved1.jpg' },
  { id: 2, label: 'Design Projects', image: '/images/design1.jpg' }
];
export default function DashboardGrid() {
  return (
    <div className="grid grid-cols-2 gap-4">
      {dashboardItems.map(item => (
        <div key={item.id} className="bg-white p-2 shadow rounded">
          <img src={item.image} alt={item.label} className="h-32 w-full object-cover rounded mb-1" />
          <div className="text-sm font-medium">{item.label}</div>
        </div>
      ))}
    </div>
  );
}