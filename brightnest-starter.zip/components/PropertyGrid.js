const properties = [
  { id: 1, location: 'Lagos', price: 1200000, type: 'Apartment', image: '/images/property1.jpg' },
  { id: 2, location: 'Abuja', price: 850000, type: 'Duplex', image: '/images/property2.jpg' }
];
export default function PropertyGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {properties.map(p => (
        <div key={p.id} className="bg-white shadow p-2 rounded-lg">
          <img src={p.image} alt={p.location} className="h-40 w-full object-cover rounded mb-2" />
          <div className="text-sm text-gray-700">{p.location}</div>
          <div className="text-md font-semibold">₦{p.price.toLocaleString()}</div>
          <div className="text-xs text-gray-500">{p.type}</div>
        </div>
      ))}
    </div>
  );
}