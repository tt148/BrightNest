export default function Footer() {
  return (
    <footer className="bg-white text-center text-sm text-gray-500 py-4 mt-10 shadow-inner">
      © {new Date().getFullYear()} BrightNest. All rights reserved.
    </footer>
  );
}