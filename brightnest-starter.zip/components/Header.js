export default function Header({ onLoginToggle }) {
  return (
    <header className="bg-white shadow p-4 flex justify-between items-center">
      <div className="text-xl font-bold">BrightNest</div>
      <nav className="space-x-4">
        <button onClick={() => onLoginToggle(prev => !prev)} className="text-gray-600 hover:text-black">
          Toggle Login
        </button>
        <a href="#" className="text-gray-600 hover:text-black">Saved Homes</a>
        <a href="#" className="text-gray-600 hover:text-black">Design Ideas</a>
        <a href="#" className="text-gray-600 hover:text-black">Messages</a>
      </nav>
    </header>
  );
}